/*1. Write a function which accepts 2 parameters (numbers) and returns their difference (use function declaration) */

function addTheNumber(number1, number2){
let result =  number1 + number2;
console.log (result);
}
addTheNumbers (4, 6); 

/* 2. Write a function  which accepts 1 parameter and returns a string  with this parameter (use function expression)*/

function subtractNumbers(number1, number2) {
 let result = number1 - number2;
 console.log(result);
}

subtractNumbers(8,2)


/* 3. Write a function that accepts firstName, lastName and returns a string "Welcome firstName, LastName" (use arrow function) */

function firstNameAndLastName(A){
   var firstName = abdi;
   var lastName = ahmednur;
   return  `Welcome ${firstName} ${lastName}`;
}
/* 4. Write a function that accepts an array and returns array without first and last elements */

function removeFirstAndLast(recipeForLaunch) {
   if (recipeForLaunch.length <= 2) {
     return [];
   }
   return recipeForLaunch.slice(1, inputArray.length - 1);
 }
 
 var recipeForLaunch = ["uncle ben rice ", "2 eggs ", "coconut water ", "avocado "];
 console.log(removeFirstAndLast(recipeForLaunch));
 