/*1. Let's use concatenation — "gluing" strings with +.

Declare a new resultString variable. Then "glue" its value from the already declared variables a, b, and c to get the string 'Concatenation'. */

const a = "Con";
const b = "enation";
const c = "cat"; 


{ console.log ( a + b + c );
}


/*2. Now let's use interpolation — inserting variables into a string using backticks (``).

Declare a new result variable. Use a string in backticks with inserted d and e variables to construct its value. The result should be the Hello, world! string. */

const d = "Hello";
const e = "world"; {
    console.log (d +" "+ e);
}
