/* -----------------------TASK------------------------------ */

/* Declare next variables:

brand with value 'Toyota';
price with value 22500;
isSedan with value true;
wings with value undefined;
owner with value null. */

const brand = "Nissan"; /* example */

const carBrand = "toyota";
const price === 22500 
const isSedan = true 

const canHaveCar = price && carBrand && isSedan { 
console.log(canHaveCar);
}

